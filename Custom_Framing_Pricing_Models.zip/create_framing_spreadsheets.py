#!/usr/bin/env python3
"""
Custom Picture Framing Linear Foot Pricing System with PID Controls
Creates comprehensive Excel spreadsheets for framing business pricing
"""

import openpyxl
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Border, Side, Alignment
from openpyxl.utils import get_column_letter
import os

def create_styles():
    """Create consistent styles for the spreadsheets"""
    styles = {}
    
    # Header style
    styles['header'] = {
        'font': Font(bold=True, size=12, color='FFFFFF'),
        'fill': PatternFill(start_color='366092', end_color='366092', fill_type='solid'),
        'alignment': Alignment(horizontal='center', vertical='center')
    }
    
    # Subheader style
    styles['subheader'] = {
        'font': Font(bold=True, size=11, color='000000'),
        'fill': PatternFill(start_color='D9E2F3', end_color='D9E2F3', fill_type='solid'),
        'alignment': Alignment(horizontal='center', vertical='center')
    }
    
    # Input style
    styles['input'] = {
        'font': Font(size=10),
        'fill': PatternFill(start_color='FFF2CC', end_color='FFF2CC', fill_type='solid'),
        'alignment': Alignment(horizontal='center', vertical='center')
    }
    
    # Formula style
    styles['formula'] = {
        'font': Font(size=10),
        'fill': PatternFill(start_color='E2EFDA', end_color='E2EFDA', fill_type='solid'),
        'alignment': Alignment(horizontal='center', vertical='center')
    }
    
    # Currency style
    styles['currency'] = {
        'font': Font(size=10),
        'alignment': Alignment(horizontal='center', vertical='center')
    }
    
    # Border
    thin_border = Border(
        left=Side(style='thin'),
        right=Side(style='thin'),
        top=Side(style='thin'),
        bottom=Side(style='thin')
    )
    
    for style in styles.values():
        style['border'] = thin_border
    
    return styles

def apply_style(cell, style_dict):
    """Apply a style dictionary to a cell"""
    if 'font' in style_dict:
        cell.font = style_dict['font']
    if 'fill' in style_dict:
        cell.fill = style_dict['fill']
    if 'alignment' in style_dict:
        cell.alignment = style_dict['alignment']
    if 'border' in style_dict:
        cell.border = style_dict['border']

def create_master_pricing_workbook():
    """Create the main pricing workbook with all sheets"""
    wb = Workbook()
    styles = create_styles()
    
    # Remove default sheet
    wb.remove(wb.active)
    
    # Create sheets
    create_master_controls_sheet(wb, styles)
    create_job_calculator_sheet(wb, styles)
    create_cost_breakdown_sheet(wb, styles)
    create_pid_controls_sheet(wb, styles)
    create_scenarios_sheet(wb, styles)
    create_documentation_sheet(wb, styles)
    
    return wb

def create_master_controls_sheet(wb, styles):
    """Create the Master Inputs & Controls sheet"""
    ws = wb.create_sheet("Master Controls", 0)
    
    # Title
    ws['A1'] = "CUSTOM FRAMING PRICING - MASTER CONTROLS"
    apply_style(ws['A1'], styles['header'])
    ws.merge_cells('A1:H1')
    
    # Global Variables Section
    ws['A3'] = "GLOBAL PRICING VARIABLES"
    apply_style(ws['A3'], styles['subheader'])
    ws.merge_cells('A3:D3')
    
    global_vars = [
        ("Labor Rate ($/hour)", "B4", 45.00),
        ("Overhead Factor (%)", "B5", 15.0),
        ("Minimum Job Charge ($)", "B6", 75.00),
        ("Waste Factor (inches)", "B7", 8.0),
        ("Default Markup (%)", "B8", 250.0)
    ]
    
    for i, (label, cell, value) in enumerate(global_vars, 4):
        ws[f'A{i}'] = label
        ws[cell] = value
        apply_style(ws[f'A{i}'], styles['subheader'])
        apply_style(ws[cell], styles['input'])
        if '$' in label or 'Charge' in label:
            ws[cell].number_format = '$#,##0.00'
        elif '%' in label:
            ws[cell].number_format = '0.0%'
    
    # Moulding Inventory Section
    ws['A10'] = "MOULDING INVENTORY"
    apply_style(ws['A10'], styles['subheader'])
    ws.merge_cells('A10:H10')
    
    moulding_headers = ["PID", "Description", "Material", "Width (in)", "Wholesale $/LF", "Markup %", "Retail $/LF", "Category"]
    for i, header in enumerate(moulding_headers, 1):
        cell = ws.cell(row=11, column=i)
        cell.value = header
        apply_style(cell, styles['header'])
    
    # Sample moulding data
    moulding_data = [
        ("M001", "Basic Wood Frame", "Pine", 1.5, 8.50, 2.5, "=E12*(1+F12)", "Basic"),
        ("M002", "Premium Oak Frame", "Oak", 2.0, 15.75, 3.0, "=E13*(1+F13)", "Premium"),
        ("M003", "Metal Silver Frame", "Aluminum", 1.0, 12.25, 2.8, "=E14*(1+F14)", "Metal"),
        ("M004", "Ornate Gold Frame", "Wood/Gold", 3.0, 28.50, 3.5, "=E15*(1+F15)", "Ornate"),
        ("M005", "Modern Black Frame", "Composite", 1.25, 9.75, 2.6, "=E16*(1+F16)", "Modern"),
        ("M006", "Rustic Barnwood", "Reclaimed Wood", 2.5, 22.00, 3.2, "=E17*(1+F17)", "Rustic"),
        ("M007", "Museum Quality", "Hardwood", 2.0, 35.00, 2.0, "=E18*(1+F18)", "Museum"),
        ("M008", "Budget Plastic", "Plastic", 1.0, 4.25, 4.0, "=E19*(1+F19)", "Budget")
    ]
    
    for i, data in enumerate(moulding_data, 12):
        for j, value in enumerate(data, 1):
            cell = ws.cell(row=i, column=j)
            if isinstance(value, str) and value.startswith('='):
                cell.value = value
                apply_style(cell, styles['formula'])
                cell.number_format = '$#,##0.00'
            elif j == 5 or j == 7:  # Price columns
                cell.value = value
                apply_style(cell, styles['input'])
                cell.number_format = '$#,##0.00'
            elif j == 6:  # Markup column
                cell.value = value
                apply_style(cell, styles['input'])
                cell.number_format = '0.0'
            else:
                cell.value = value
                apply_style(cell, styles['input'])
    
    # Glazing Options Section
    ws['A21'] = "GLAZING OPTIONS"
    apply_style(ws['A21'], styles['subheader'])
    ws.merge_cells('A21:F21')
    
    glazing_headers = ["GID", "Description", "Type", "Wholesale $/SqFt", "Markup %", "Retail $/SqFt"]
    for i, header in enumerate(glazing_headers, 1):
        cell = ws.cell(row=22, column=i)
        cell.value = header
        apply_style(cell, styles['header'])
    
    glazing_data = [
        ("G001", "Regular Glass", "Glass", 3.50, 2.5, "=D23*(1+E23)"),
        ("G002", "Non-Glare Glass", "Glass", 8.75, 2.2, "=D24*(1+E24)"),
        ("G003", "UV Protection Glass", "Glass", 12.50, 2.0, "=D25*(1+E25)"),
        ("G004", "Museum Glass", "Glass", 25.00, 1.8, "=D26*(1+E26)"),
        ("G005", "Acrylic Standard", "Acrylic", 4.25, 2.3, "=D27*(1+E27)"),
        ("G006", "Acrylic UV", "Acrylic", 9.50, 2.1, "=D28*(1+E28)")
    ]
    
    for i, data in enumerate(glazing_data, 23):
        for j, value in enumerate(data, 1):
            cell = ws.cell(row=i, column=j)
            if isinstance(value, str) and value.startswith('='):
                cell.value = value
                apply_style(cell, styles['formula'])
                cell.number_format = '$#,##0.00'
            elif j == 4 or j == 6:  # Price columns
                cell.value = value
                apply_style(cell, styles['input'])
                cell.number_format = '$#,##0.00'
            elif j == 5:  # Markup column
                cell.value = value
                apply_style(cell, styles['input'])
                cell.number_format = '0.0'
            else:
                cell.value = value
                apply_style(cell, styles['input'])
    
    # Matboard Options Section
    ws['A30'] = "MATBOARD OPTIONS"
    apply_style(ws['A30'], styles['subheader'])
    ws.merge_cells('A30:F30')
    
    matboard_headers = ["MID", "Description", "Quality", "Wholesale $/SqFt", "Markup %", "Retail $/SqFt"]
    for i, header in enumerate(matboard_headers, 1):
        cell = ws.cell(row=31, column=i)
        cell.value = header
        apply_style(cell, styles['header'])
    
    matboard_data = [
        ("MAT001", "Standard Mat", "Regular", 2.25, 3.0, "=D32*(1+E32)"),
        ("MAT002", "Acid-Free Mat", "Conservation", 4.50, 2.5, "=D33*(1+E33)"),
        ("MAT003", "Museum Mat", "Museum", 8.75, 2.0, "=D34*(1+E34)"),
        ("MAT004", "Fabric Mat", "Specialty", 12.00, 2.2, "=D35*(1+E35)"),
        ("MAT005", "Double Mat", "Premium", 6.25, 2.3, "=D36*(1+E36)")
    ]
    
    for i, data in enumerate(matboard_data, 32):
        for j, value in enumerate(data, 1):
            cell = ws.cell(row=i, column=j)
            if isinstance(value, str) and value.startswith('='):
                cell.value = value
                apply_style(cell, styles['formula'])
                cell.number_format = '$#,##0.00'
            elif j == 4 or j == 6:  # Price columns
                cell.value = value
                apply_style(cell, styles['input'])
                cell.number_format = '$#,##0.00'
            elif j == 5:  # Markup column
                cell.value = value
                apply_style(cell, styles['input'])
                cell.number_format = '0.0'
            else:
                cell.value = value
                apply_style(cell, styles['input'])
    
    # Auto-fit columns
    for column in ws.columns:
        max_length = 0
        column_letter = get_column_letter(column[0].column)
        for cell in column:
            try:
                if len(str(cell.value)) > max_length:
                    max_length = len(str(cell.value))
            except:
                pass
        adjusted_width = min(max_length + 2, 20)
        ws.column_dimensions[column_letter].width = adjusted_width

def create_job_calculator_sheet(wb, styles):
    """Create the Job Calculator sheet"""
    ws = wb.create_sheet("Job Calculator")
    
    # Title
    ws['A1'] = "CUSTOM FRAMING JOB CALCULATOR"
    apply_style(ws['A1'], styles['header'])
    ws.merge_cells('A1:H1')
    
    # Customer Information Section
    ws['A3'] = "CUSTOMER INFORMATION"
    apply_style(ws['A3'], styles['subheader'])
    ws.merge_cells('A3:D3')
    
    customer_fields = [
        ("Customer Name:", "B4"),
        ("Job Date:", "B5"),
        ("Job Number:", "B6")
    ]
    
    for label, cell in customer_fields:
        row = int(cell[1:])
        ws[f'A{row}'] = label
        apply_style(ws[f'A{row}'], styles['subheader'])
        apply_style(ws[cell], styles['input'])
    
    # Artwork Dimensions Section
    ws['A8'] = "ARTWORK DIMENSIONS"
    apply_style(ws['A8'], styles['subheader'])
    ws.merge_cells('A8:D8')
    
    ws['A9'] = "Width (inches):"
    ws['B9'] = 16
    ws['A10'] = "Height (inches):"
    ws['B10'] = 20
    
    apply_style(ws['A9'], styles['subheader'])
    apply_style(ws['B9'], styles['input'])
    apply_style(ws['A10'], styles['subheader'])
    apply_style(ws['B10'], styles['input'])
    
    # Material Selection Section
    ws['A12'] = "MATERIAL SELECTION"
    apply_style(ws['A12'], styles['subheader'])
    ws.merge_cells('A12:D12')
    
    ws['A13'] = "Moulding PID:"
    ws['B13'] = "M001"
    ws['A14'] = "Glazing GID:"
    ws['B14'] = "G001"
    ws['A15'] = "Matboard MID:"
    ws['B15'] = "MAT001"
    
    for row in [13, 14, 15]:
        apply_style(ws[f'A{row}'], styles['subheader'])
        apply_style(ws[f'B{row}'], styles['input'])
    
    # Calculations Section
    ws['A17'] = "CALCULATIONS"
    apply_style(ws['A17'], styles['subheader'])
    ws.merge_cells('A17:H17')
    
    calc_headers = ["Component", "Quantity", "Unit", "Unit Price", "Total Cost", "Description"]
    for i, header in enumerate(calc_headers, 1):
        cell = ws.cell(row=18, column=i)
        cell.value = header
        apply_style(cell, styles['header'])
    
    # Calculation formulas
    calculations = [
        ("Frame Perimeter", "=2*(B9+B10)", "inches", "", "", "Total frame perimeter"),
        ("Linear Feet Required", "=B19/12", "feet", "", "", "Perimeter converted to feet"),
        ("Linear Feet + Waste", "=B20+'Master Controls'.$B$7/12", "feet", "", "", "Adding waste factor"),
        ("Moulding Cost", "=B21", "feet", "=VLOOKUP(B13,'Master Controls'.$A$12:$H$19,7,FALSE)", "=B22*D22", "Frame moulding total"),
        ("Artwork Area", "=B9*B10/144", "sq ft", "", "", "Area in square feet"),
        ("Glazing Cost", "=B24", "sq ft", "=VLOOKUP(B14,'Master Controls'.$A$23:$F$28,6,FALSE)", "=B24*D24", "Glass/acrylic total"),
        ("Matboard Cost", "=B24", "sq ft", "=VLOOKUP(B15,'Master Controls'.$A$32:$F$36,6,FALSE)", "=B24*D26", "Matboard total"),
        ("Labor Time", "=0.5+B24*0.25", "hours", "='Master Controls'.$B$4", "=B27*D27", "Estimated labor time"),
        ("Hardware & Misc", "1", "job", "15.00", "=B28*D28", "Hanging hardware, etc.")
    ]
    
    for i, (component, qty_formula, unit, price_formula, total_formula, desc) in enumerate(calculations, 19):
        ws[f'A{i}'] = component
        ws[f'B{i}'] = qty_formula
        ws[f'C{i}'] = unit
        ws[f'D{i}'] = price_formula if price_formula else ""
        ws[f'E{i}'] = total_formula
        ws[f'F{i}'] = desc
        
        apply_style(ws[f'A{i}'], styles['subheader'])
        apply_style(ws[f'B{i}'], styles['formula'])
        apply_style(ws[f'C{i}'], styles['input'])
        apply_style(ws[f'D{i}'], styles['formula'])
        apply_style(ws[f'E{i}'], styles['formula'])
        apply_style(ws[f'F{i}'], styles['input'])
        
        if 'Cost' in component or i >= 22:
            ws[f'D{i}'].number_format = '$#,##0.00'
            ws[f'E{i}'].number_format = '$#,##0.00'
    
    # Summary Section
    ws['A29'] = "PRICING SUMMARY"
    apply_style(ws['A29'], styles['subheader'])
    ws.merge_cells('A29:D29')
    
    summary_items = [
        ("Subtotal (Materials + Labor):", "=SUM(E22,E25,E26,E27,E28)", "B30"),
        ("Overhead (%):", "='Master Controls'.$B$5", "B31"),
        ("Overhead Amount:", "=B30*B31", "B32"),
        ("Total Before Profit:", "=B30+B32", "B33"),
        ("Minimum Job Check:", "=MAX(B33,'Master Controls'.$B$6)", "B34"),
        ("FINAL PRICE:", "=B34", "B35")
    ]
    
    for i, (label, formula, cell) in enumerate(summary_items, 30):
        ws[f'A{i}'] = label
        ws[cell] = formula
        
        if i == 35:  # Final price
            apply_style(ws[f'A{i}'], styles['header'])
            apply_style(ws[cell], styles['header'])
        else:
            apply_style(ws[f'A{i}'], styles['subheader'])
            apply_style(ws[cell], styles['formula'])
        
        ws[cell].number_format = '$#,##0.00' if '$' in label or 'PRICE' in label else '0.0%'
    
    # Auto-fit columns
    for column in ws.columns:
        max_length = 0
        column_letter = get_column_letter(column[0].column)
        for cell in column:
            try:
                if len(str(cell.value)) > max_length:
                    max_length = len(str(cell.value))
            except:
                pass
        adjusted_width = min(max_length + 2, 25)
        ws.column_dimensions[column_letter].width = adjusted_width

def create_cost_breakdown_sheet(wb, styles):
    """Create the Cost Breakdown Analysis sheet"""
    ws = wb.create_sheet("Cost Breakdown")
    
    # Title
    ws['A1'] = "COST BREAKDOWN ANALYSIS"
    apply_style(ws['A1'], styles['header'])
    ws.merge_cells('A1:H1')
    
    # Cost Categories Section
    ws['A3'] = "COST CATEGORY ANALYSIS"
    apply_style(ws['A3'], styles['subheader'])
    ws.merge_cells('A3:H3')
    
    headers = ["Category", "Wholesale Cost", "Markup %", "Retail Price", "Profit $", "Profit %", "% of Total Job"]
    for i, header in enumerate(headers, 1):
        cell = ws.cell(row=4, column=i)
        cell.value = header
        apply_style(cell, styles['header'])
    
    # Cost breakdown formulas referencing Job Calculator
    cost_categories = [
        ("Moulding", "='Job Calculator'.D22*'Job Calculator'.B22", "=('Job Calculator'.E22/'Job Calculator'.D22/'Job Calculator'.B22-1)", 
         "='Job Calculator'.E22", "='Job Calculator'.E22-B5", "=E5/D5", "=D5/'Job Calculator'.$B$35"),
        ("Glazing", "='Job Calculator'.D24*'Job Calculator'.B24", "=('Job Calculator'.E25/'Job Calculator'.D24/'Job Calculator'.B24-1)", 
         "='Job Calculator'.E25", "='Job Calculator'.E25-B6", "=E6/D6", "=D6/'Job Calculator'.$B$35"),
        ("Matboard", "='Job Calculator'.D26*'Job Calculator'.B24", "=('Job Calculator'.E26/'Job Calculator'.D26/'Job Calculator'.B24-1)", 
         "='Job Calculator'.E26", "='Job Calculator'.E26-B7", "=E7/D7", "=D7/'Job Calculator'.$B$35"),
        ("Labor", "='Job Calculator'.D27*'Job Calculator'.B27", "0", 
         "='Job Calculator'.E27", "=0", "=0", "=D8/'Job Calculator'.$B$35"),
        ("Hardware", "='Job Calculator'.D28", "=('Job Calculator'.E28/'Job Calculator'.D28-1)", 
         "='Job Calculator'.E28", "='Job Calculator'.E28-B9", "=E9/D9", "=D9/'Job Calculator'.$B$35"),
        ("Overhead", "0", "N/A", 
         "='Job Calculator'.B32", "='Job Calculator'.B32", "=100%", "=D10/'Job Calculator'.$B$35")
    ]
    
    for i, (category, wholesale, markup, retail, profit_dollar, profit_pct, pct_total) in enumerate(cost_categories, 5):
        ws[f'A{i}'] = category
        ws[f'B{i}'] = wholesale
        ws[f'C{i}'] = markup
        ws[f'D{i}'] = retail
        ws[f'E{i}'] = profit_dollar
        ws[f'F{i}'] = profit_pct
        ws[f'G{i}'] = pct_total
        
        apply_style(ws[f'A{i}'], styles['subheader'])
        for col in ['B', 'C', 'D', 'E', 'F', 'G']:
            apply_style(ws[f'{col}{i}'], styles['formula'])
            if col in ['B', 'D', 'E']:
                ws[f'{col}{i}'].number_format = '$#,##0.00'
            elif col in ['C', 'F', 'G']:
                ws[f'{col}{i}'].number_format = '0.0%'
    
    # Totals row
    ws['A11'] = "TOTALS"
    ws['B11'] = "=SUM(B5:B10)"
    ws['D11'] = "='Job Calculator'.B35"
    ws['E11'] = "=SUM(E5:E10)"
    ws['F11'] = "=E11/D11"
    ws['G11'] = "=SUM(G5:G10)"
    
    apply_style(ws['A11'], styles['header'])
    for col in ['B', 'D', 'E', 'F', 'G']:
        apply_style(ws[f'{col}11'], styles['header'])
        if col in ['B', 'D', 'E']:
            ws[f'{col}11'].number_format = '$#,##0.00'
        elif col in ['F', 'G']:
            ws[f'{col}11'].number_format = '0.0%'
    
    # Profitability Analysis Section
    ws['A14'] = "PROFITABILITY METRICS"
    apply_style(ws['A14'], styles['subheader'])
    ws.merge_cells('A14:D14')
    
    metrics = [
        ("Total Job Revenue:", "='Job Calculator'.B35", "B15"),
        ("Total Job Cost:", "=B11", "B16"),
        ("Gross Profit:", "=B15-B16", "B17"),
        ("Gross Margin %:", "=B17/B15", "B18"),
        ("Markup %:", "=B17/B16", "B19"),
        ("Break-even Revenue:", "=B16", "B20"),
        ("Revenue per Linear Foot:", "=B15/'Job Calculator'.B21", "B21"),
        ("Profit per Linear Foot:", "=B17/'Job Calculator'.B21", "B22")
    ]
    
    for i, (label, formula, cell) in enumerate(metrics, 15):
        ws[f'A{i}'] = label
        ws[cell] = formula
        
        apply_style(ws[f'A{i}'], styles['subheader'])
        apply_style(ws[cell], styles['formula'])
        
        if '$' in label or 'Revenue' in label or 'Profit' in label or 'Cost' in label:
            ws[cell].number_format = '$#,##0.00'
        elif '%' in label:
            ws[cell].number_format = '0.0%'
    
    # Auto-fit columns
    for column in ws.columns:
        max_length = 0
        column_letter = get_column_letter(column[0].column)
        for cell in column:
            try:
                if len(str(cell.value)) > max_length:
                    max_length = len(str(cell.value))
            except:
                pass
        adjusted_width = min(max_length + 2, 20)
        ws.column_dimensions[column_letter].width = adjusted_width

def create_pid_controls_sheet(wb, styles):
    """Create the PID Controls sheet for dynamic pricing adjustments"""
    ws = wb.create_sheet("PID Controls")
    
    # Title
    ws['A1'] = "PID PRICING CONTROL SYSTEM"
    apply_style(ws['A1'], styles['header'])
    ws.merge_cells('A1:H1')
    
    # Explanation
    ws['A3'] = "PID Control System for Dynamic Pricing Adjustments"
    apply_style(ws['A3'], styles['subheader'])
    ws.merge_cells('A3:H3')
    
    ws['A4'] = "P = Proportional (Current market conditions)"
    ws['A5'] = "I = Integral (Historical performance trends)"
    ws['A6'] = "D = Derivative (Rate of change in market)"
    
    for row in [4, 5, 6]:
        apply_style(ws[f'A{row}'], styles['input'])
    
    # PID Parameters Section
    ws['A8'] = "PID CONTROL PARAMETERS"
    apply_style(ws['A8'], styles['subheader'])
    ws.merge_cells('A8:D8')
    
    pid_params = [
        ("Proportional Gain (Kp)", "B9", 1.0, "Sensitivity to current market conditions"),
        ("Integral Gain (Ki)", "B10", 0.1, "Response to historical trends"),
        ("Derivative Gain (Kd)", "B11", 0.05, "Response to rate of change"),
        ("Setpoint (Target Margin %)", "B12", 0.50, "Target profit margin")
    ]
    
    for label, cell, value, desc in pid_params:
        row = int(cell[1:])
        ws[f'A{row}'] = label
        ws[cell] = value
        ws[f'D{row}'] = desc
        
        apply_style(ws[f'A{row}'], styles['subheader'])
        apply_style(ws[cell], styles['input'])
        apply_style(ws[f'D{row}'], styles['input'])
        
        if '%' in label:
            ws[cell].number_format = '0.0%'
    
    # Market Conditions Input Section
    ws['A14'] = "MARKET CONDITIONS INPUT"
    apply_style(ws['A14'], styles['subheader'])
    ws.merge_cells('A14:D14')
    
    market_inputs = [
        ("Current Market Demand", "B15", 0.8, "Scale: 0.0 (Low) to 1.0 (High)"),
        ("Competition Level", "B16", 0.6, "Scale: 0.0 (Low) to 1.0 (High)"),
        ("Material Cost Trend", "B17", 0.1, "Scale: -1.0 (Decreasing) to 1.0 (Increasing)"),
        ("Economic Conditions", "B18", 0.7, "Scale: 0.0 (Poor) to 1.0 (Excellent)"),
        ("Seasonal Factor", "B19", 0.9, "Scale: 0.0 (Off-season) to 1.0 (Peak)")
    ]
    
    for label, cell, value, desc in market_inputs:
        row = int(cell[1:])
        ws[f'A{row}'] = label
        ws[cell] = value
        ws[f'D{row}'] = desc
        
        apply_style(ws[f'A{row}'], styles['subheader'])
        apply_style(ws[cell], styles['input'])
        apply_style(ws[f'D{row}'], styles['input'])
    
    # Historical Performance Section
    ws['A21'] = "HISTORICAL PERFORMANCE (Last 12 Months)"
    apply_style(ws['A21'], styles['subheader'])
    ws.merge_cells('A21:F21')
    
    hist_headers = ["Month", "Revenue", "Margin %", "Jobs Count", "Avg Job Value", "Market Score"]
    for i, header in enumerate(hist_headers, 1):
        cell = ws.cell(row=22, column=i)
        cell.value = header
        apply_style(cell, styles['header'])
    
    # Sample historical data
    months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
    for i, month in enumerate(months, 23):
        ws[f'A{i}'] = month
        ws[f'B{i}'] = f"=15000+RANDBETWEEN(-3000,5000)"  # Revenue
        ws[f'C{i}'] = f"=0.45+RANDBETWEEN(-5,10)/100"     # Margin
        ws[f'D{i}'] = f"=50+RANDBETWEEN(-15,25)"          # Jobs
        ws[f'E{i}'] = f"=B{i}/D{i}"                       # Avg job value
        ws[f'F{i}'] = f"=(B15+B18+B19)/3"                 # Market score
        
        apply_style(ws[f'A{i}'], styles['input'])
        for col in ['B', 'C', 'D', 'E', 'F']:
            apply_style(ws[f'{col}{i}'], styles['formula'])
            if col in ['B', 'E']:
                ws[f'{col}{i}'].number_format = '$#,##0'
            elif col == 'C':
                ws[f'{col}{i}'].number_format = '0.0%'
            elif col == 'F':
                ws[f'{col}{i}'].number_format = '0.00'
    
    # PID Calculations Section
    ws['A36'] = "PID CALCULATIONS"
    apply_style(ws['A36'], styles['subheader'])
    ws.merge_cells('A36:D36')
    
    # Current performance
    ws['A37'] = "Current Margin %:"
    ws['B37'] = "='Cost Breakdown'.F11"
    ws['A38'] = "Error (Setpoint - Current):"
    ws['B38'] = "=B12-B37"
    
    # PID components
    ws['A40'] = "Proportional Component:"
    ws['B40'] = "=B9*B38"
    ws['A41'] = "Integral Component:"
    ws['B41'] = "=B10*AVERAGE(C23:C34)-B12"  # Historical average vs setpoint
    ws['A42'] = "Derivative Component:"
    ws['B42'] = "=B11*(C34-C33)"  # Rate of change (last month vs previous)
    
    # PID Output
    ws['A44'] = "PID Output (Adjustment Factor):"
    ws['B44'] = "=B40+B41+B42"
    ws['A45'] = "Recommended Markup Adjustment:"
    ws['B45'] = "=B44*100"  # Convert to percentage points
    
    # Apply PID adjustment
    ws['A47'] = "ADJUSTED PRICING FACTORS"
    apply_style(ws['A47'], styles['subheader'])
    ws.merge_cells('A47:D47')
    
    ws['A48'] = "Base Markup %:"
    ws['B48'] = "='Master Controls'.B8/100"
    ws['A49'] = "PID Adjustment:"
    ws['B49'] = "=B45/100"
    ws['A50'] = "Market Condition Factor:"
    ws['B50'] = "=(B15*B18*B19)^0.5-0.5"  # Geometric mean of market factors
    ws['A51'] = "Final Markup Multiplier:"
    ws['B51'] = "=1+B48+B49+B50"
    
    # Style the PID calculation cells
    for row in range(37, 52):
        if ws[f'A{row}'].value:
            apply_style(ws[f'A{row}'], styles['subheader'])
            apply_style(ws[f'B{row}'], styles['formula'])
            if 'Margin' in str(ws[f'A{row}'].value) or '%' in str(ws[f'A{row}'].value):
                ws[f'B{row}'].number_format = '0.0%'
            elif 'Factor' in str(ws[f'A{row}'].value) or 'Multiplier' in str(ws[f'A{row}'].value):
                ws[f'B{row}'].number_format = '0.000'
    
    # Auto-fit columns
    for column in ws.columns:
        max_length = 0
        column_letter = get_column_letter(column[0].column)
        for cell in column:
            try:
                if len(str(cell.value)) > max_length:
                    max_length = len(str(cell.value))
            except:
                pass
        adjusted_width = min(max_length + 2, 30)
        ws.column_dimensions[column_letter].width = adjusted_width

def create_scenarios_sheet(wb, styles):
    """Create the Pricing Scenarios sheet"""
    ws = wb.create_sheet("Pricing Scenarios")
    
    # Title
    ws['A1'] = "PRICING SCENARIOS ANALYSIS"
    apply_style(ws['A1'], styles['header'])
    ws.merge_cells('A1:J1')
    
    # Scenario Setup Section
    ws['A3'] = "SCENARIO PARAMETERS"
    apply_style(ws['A3'], styles['subheader'])
    ws.merge_cells('A3:J3')
    
    # Headers for scenarios
    scenario_headers = ["Parameter", "Base Case", "High Demand", "Economic Downturn", "Premium Market", "Budget Market"]
    for i, header in enumerate(scenario_headers, 1):
        cell = ws.cell(row=4, column=i)
        cell.value = header
        apply_style(cell, styles['header'])
    
    # Scenario parameters
    scenario_data = [
        ("Market Demand", 0.8, 1.0, 0.4, 0.9, 0.6),
        ("Competition Level", 0.6, 0.8, 0.5, 0.4, 0.9),
        ("Economic Conditions", 0.7, 0.9, 0.3, 0.8, 0.5),
        ("Target Margin %", 0.50, 0.55, 0.40, 0.60, 0.35),
        ("Base Markup %", 2.5, 3.0, 2.0, 3.5, 1.8)
    ]
    
    for i, data in enumerate(scenario_data, 5):
        for j, value in enumerate(data):
            cell = ws.cell(row=i, column=j+1)
            cell.value = value
            if j == 0:
                apply_style(cell, styles['subheader'])
            else:
                apply_style(cell, styles['input'])
                if 'Margin' in data[0] or '%' in data[0]:
                    cell.number_format = '0.0%' if value < 1 else '0.0'
    
    # Sample Frame Calculations
    ws['A11'] = "SAMPLE FRAME PRICING (16x20 inch artwork)"
    apply_style(ws['A11'], styles['subheader'])
    ws.merge_cells('A11:J11')
    
    # Frame types for comparison
    frame_types = [
        ("Basic Wood (M001)", "M001", "G001", "MAT001"),
        ("Premium Oak (M002)", "M002", "G002", "MAT002"),
        ("Metal Silver (M003)", "M003", "G003", "MAT003"),
        ("Ornate Gold (M004)", "M004", "G004", "MAT004")
    ]
    
    # Headers for frame pricing
    pricing_headers = ["Frame Type", "Base Price", "High Demand", "Economic Downturn", "Premium Market", "Budget Market"]
    for i, header in enumerate(pricing_headers, 1):
        cell = ws.cell(row=12, column=i)
        cell.value = header
        apply_style(cell, styles['header'])
    
    # Calculate prices for each scenario
    for i, (frame_name, mid, gid, matid) in enumerate(frame_types, 13):
        ws[f'A{i}'] = frame_name
        apply_style(ws[f'A{i}'], styles['subheader'])
        
        # Base calculations (16x20 = 72 inch perimeter = 6 linear feet)
        base_formula = f"=6*VLOOKUP('{mid}','Master Controls'.$A$12:$H$19,7,FALSE)+((16*20)/144)*VLOOKUP('{gid}','Master Controls'.$A$23:$F$28,6,FALSE)+((16*20)/144)*VLOOKUP('{matid}','Master Controls'.$A$32:$F$36,6,FALSE)+45+15"
        
        # Scenario adjustments
        scenarios = [
            ("", base_formula),  # Base case
            ("*C5", f"=({base_formula})*C5"),  # High demand
            ("*D5", f"=({base_formula})*D5"),  # Economic downturn
            ("*E5", f"=({base_formula})*E5"),  # Premium market
            ("*F5", f"=({base_formula})*F5")   # Budget market
        ]
        
        for j, (suffix, formula) in enumerate(scenarios, 2):
            cell = ws.cell(row=i, column=j)
            cell.value = formula
            apply_style(cell, styles['formula'])
            cell.number_format = '$#,##0.00'
    
    # Scenario Analysis Summary
    ws['A18'] = "SCENARIO IMPACT ANALYSIS"
    apply_style(ws['A18'], styles['subheader'])
    ws.merge_cells('A18:J18')
    
    analysis_headers = ["Metric", "Base Case", "High Demand", "Economic Downturn", "Premium Market", "Budget Market"]
    for i, header in enumerate(analysis_headers, 1):
        cell = ws.cell(row=19, column=i)
        cell.value = header
        apply_style(cell, styles['header'])
    
    # Analysis metrics
    analysis_data = [
        ("Average Frame Price", "=AVERAGE(B13:B16)", "=AVERAGE(C13:C16)", "=AVERAGE(D13:D16)", "=AVERAGE(E13:E16)", "=AVERAGE(F13:F16)"),
        ("Price Range (Max-Min)", "=MAX(B13:B16)-MIN(B13:B16)", "=MAX(C13:C16)-MIN(C13:C16)", "=MAX(D13:D16)-MIN(D13:D16)", "=MAX(E13:E16)-MIN(E13:E16)", "=MAX(F13:F16)-MIN(F13:F16)"),
        ("% Change from Base", "0%", "=(C20-B20)/B20", "=(D20-B20)/B20", "=(E20-B20)/B20", "=(F20-B20)/B20"),
        ("Estimated Monthly Revenue", "=B20*60", "=C20*80", "=D20*35", "=E20*45", "=F20*75"),
        ("Revenue Change from Base", "$0", "=C23-B23", "=D23-B23", "=E23-B23", "=F23-B23")
    ]
    
    for i, data in enumerate(analysis_data, 20):
        for j, formula in enumerate(data):
            cell = ws.cell(row=i, column=j+1)
            if j == 0:
                cell.value = formula
                apply_style(cell, styles['subheader'])
            else:
                cell.value = formula
                apply_style(cell, styles['formula'])
                if '$' in data[0] or 'Revenue' in data[0]:
                    cell.number_format = '$#,##0'
                elif '%' in data[0] or 'Change' in data[0]:
                    cell.number_format = '0.0%'
    
    # Auto-fit columns
    for column in ws.columns:
        max_length = 0
        column_letter = get_column_letter(column[0].column)
        for cell in column:
            try:
                if len(str(cell.value)) > max_length:
                    max_length = len(str(cell.value))
            except:
                pass
        adjusted_width = min(max_length + 2, 18)
        ws.column_dimensions[column_letter].width = adjusted_width

def create_documentation_sheet(wb, styles):
    """Create the Documentation sheet with formulas and instructions"""
    ws = wb.create_sheet("Documentation")
    
    # Title
    ws['A1'] = "FRAMING PRICING SYSTEM DOCUMENTATION"
    apply_style(ws['A1'], styles['header'])
    ws.merge_cells('A1:H1')
    
    # System Overview
    ws['A3'] = "SYSTEM OVERVIEW"
    apply_style(ws['A3'], styles['subheader'])
    ws.merge_cells('A3:H3')
    
    overview_text = [
        "This Excel workbook implements a comprehensive linear foot pricing system for custom picture framing.",
        "The system includes PID (Proportional-Integral-Derivative) controls for dynamic price adjustments",
        "based on market conditions, historical performance, and business objectives.",
        "",
        "SHEET DESCRIPTIONS:",
        "• Master Controls: Central parameter control panel for all pricing variables",
        "• Job Calculator: Interactive calculator for individual customer quotes",
        "• Cost Breakdown: Detailed analysis of costs, margins, and profitability",
        "• PID Controls: Dynamic pricing adjustment system based on market conditions",
        "• Pricing Scenarios: Comparison of different market scenarios and their impact",
        "• Documentation: This sheet with formulas and usage instructions"
    ]
    
    for i, text in enumerate(overview_text, 4):
        ws[f'A{i}'] = text
        apply_style(ws[f'A{i}'], styles['input'])
    
    # Key Formulas Section
    ws['A16'] = "KEY FORMULAS AND CALCULATIONS"
    apply_style(ws['A16'], styles['subheader'])
    ws.merge_cells('A16:H16')
    
    formula_headers = ["Formula Name", "Excel Formula", "Description", "Sheet Location"]
    for i, header in enumerate(formula_headers, 1):
        cell = ws.cell(row=17, column=i)
        cell.value = header
        apply_style(cell, styles['header'])
    
    key_formulas = [
        ("Linear Feet Calculation", "=2*(Width+Height)/12", "Converts frame perimeter to linear feet", "Job Calculator B20"),
        ("Moulding Cost", "=LinearFeet*VLOOKUP(PID,MouldingTable,7,FALSE)", "Calculates moulding cost using lookup", "Job Calculator E22"),
        ("Area Calculation", "=Width*Height/144", "Converts artwork dimensions to square feet", "Job Calculator B24"),
        ("Labor Time Estimate", "=0.5+Area*0.25", "Estimates labor hours based on size", "Job Calculator B27"),
        ("Overhead Calculation", "=Subtotal*OverheadFactor", "Applies overhead percentage to subtotal", "Job Calculator B32"),
        ("Profit Margin", "=(Revenue-Cost)/Revenue", "Calculates profit margin percentage", "Cost Breakdown F11"),
        ("PID Error", "=Setpoint-CurrentMargin", "Calculates error for PID control", "PID Controls B38"),
        ("PID Output", "=Kp*Error+Ki*IntegralTerm+Kd*DerivativeTerm", "PID control algorithm output", "PID Controls B44"),
        ("Market Adjustment", "=(Demand*Economic*Seasonal)^0.5-0.5", "Market condition adjustment factor", "PID Controls B50"),
        ("Final Price", "=MAX(CalculatedPrice,MinimumCharge)", "Ensures minimum charge is met", "Job Calculator B34")
    ]
    
    for i, (name, formula, desc, location) in enumerate(key_formulas, 18):
        ws[f'A{i}'] = name
        ws[f'B{i}'] = formula
        ws[f'C{i}'] = desc
        ws[f'D{i}'] = location
        
        apply_style(ws[f'A{i}'], styles['subheader'])
        for col in ['B', 'C', 'D']:
            apply_style(ws[f'{col}{i}'], styles['input'])
    
    # Usage Instructions
    ws['A29'] = "USAGE INSTRUCTIONS"
    apply_style(ws['A29'], styles['subheader'])
    ws.merge_cells('A29:H29')
    
    instructions = [
        "STEP 1: Set up Master Controls",
        "• Update global variables (labor rate, overhead, minimum charge)",
        "• Add your moulding inventory with wholesale costs and desired markups",
        "• Add glazing and matboard options with pricing",
        "",
        "STEP 2: Use Job Calculator for quotes",
        "• Enter customer information and artwork dimensions",
        "• Select materials using dropdown menus (PIDs)",
        "• Review calculated pricing and adjust if needed",
        "",
        "STEP 3: Monitor Cost Breakdown",
        "• Review profitability metrics for each job",
        "• Analyze cost categories and margins",
        "• Identify opportunities for improvement",
        "",
        "STEP 4: Adjust PID Controls",
        "• Update market condition inputs regularly",
        "• Review historical performance data",
        "• Apply PID-recommended adjustments to Master Controls",
        "",
        "STEP 5: Analyze Scenarios",
        "• Compare pricing under different market conditions",
        "• Plan for seasonal variations and economic changes",
        "• Optimize pricing strategy based on scenarios"
    ]
    
    for i, instruction in enumerate(instructions, 30):
        ws[f'A{i}'] = instruction
        if instruction.startswith("STEP"):
            apply_style(ws[f'A{i}'], styles['subheader'])
        else:
            apply_style(ws[f'A{i}'], styles['input'])
    
    # PID Control Explanation
    ws['A52'] = "PID CONTROL SYSTEM EXPLANATION"
    apply_style(ws['A52'], styles['subheader'])
    ws.merge_cells('A52:H52')
    
    pid_explanation = [
        "The PID control system automatically adjusts pricing based on three components:",
        "",
        "PROPORTIONAL (P): Responds to current market conditions",
        "• Higher demand = increase prices",
        "• Strong competition = decrease prices",
        "• Good economic conditions = increase prices",
        "",
        "INTEGRAL (I): Responds to historical performance trends",
        "• Consistently below target margin = increase prices",
        "• Consistently above target margin = decrease prices",
        "",
        "DERIVATIVE (D): Responds to rate of change",
        "• Rapidly improving performance = maintain current strategy",
        "• Rapidly declining performance = make larger adjustments",
        "",
        "The system outputs an adjustment factor that can be applied to your base markup",
        "percentages to optimize profitability while remaining competitive."
    ]
    
    for i, text in enumerate(pid_explanation, 53):
        ws[f'A{i}'] = text
        if text.startswith(("PROPORTIONAL", "INTEGRAL", "DERIVATIVE")):
            apply_style(ws[f'A{i}'], styles['subheader'])
        else:
            apply_style(ws[f'A{i}'], styles['input'])
    
    # Auto-fit columns
    for column in ws.columns:
        max_length = 0
        column_letter = get_column_letter(column[0].column)
        for cell in column:
            try:
                if len(str(cell.value)) > max_length:
                    max_length = len(str(cell.value))
            except:
                pass
        adjusted_width = min(max_length + 2, 50)
        ws.column_dimensions[column_letter].width = adjusted_width

def main():
    """Main function to create all spreadsheets"""
    print("Creating Custom Framing Pricing Spreadsheets...")
    
    # Create main workbook
    wb = create_master_pricing_workbook()
    
    # Save the main workbook
    main_file = "/home/ubuntu/framing_pricing_spreadsheets/Custom_Framing_Pricing_System.xlsx"
    wb.save(main_file)
    print(f"Created: {main_file}")
    
    # Create additional specialized workbooks
    create_quick_calculator()
    create_inventory_manager()
    create_profit_analyzer()
    
    print("\nAll spreadsheets created successfully!")
    print("Files created in ~/framing_pricing_spreadsheets/:")
    print("1. Custom_Framing_Pricing_System.xlsx - Main comprehensive system")
    print("2. Quick_Price_Calculator.xlsx - Simplified calculator")
    print("3. Inventory_Manager.xlsx - Material inventory tracking")
    print("4. Profit_Analyzer.xlsx - Advanced profitability analysis")

def create_quick_calculator():
    """Create a simplified quick calculator workbook"""
    wb = Workbook()
    styles = create_styles()
    ws = wb.active
    ws.title = "Quick Calculator"
    
    # Title
    ws['A1'] = "QUICK FRAMING PRICE CALCULATOR"
    apply_style(ws['A1'], styles['header'])
    ws.merge_cells('A1:F1')
    
    # Simple input section
    ws['A3'] = "ARTWORK SIZE"
    apply_style(ws['A3'], styles['subheader'])
    ws['A4'] = "Width (inches):"
    ws['B4'] = 16
    ws['A5'] = "Height (inches):"
    ws['B5'] = 20
    
    # Frame type selection
    ws['A7'] = "FRAME TYPE"
    apply_style(ws['A7'], styles['subheader'])
    ws['A8'] = "Basic ($12/LF)"
    ws['A9'] = "Premium ($25/LF)"
    ws['A10'] = "Deluxe ($40/LF)"
    
    # Quick calculations
    ws['D4'] = "Linear Feet:"
    ws['E4'] = "=2*(B4+B5)/12"
    ws['D5'] = "Basic Price:"
    ws['E5'] = "=E4*12+50"
    ws['D6'] = "Premium Price:"
    ws['E6'] = "=E4*25+75"
    ws['D7'] = "Deluxe Price:"
    ws['E7'] = "=E4*40+100"
    
    # Apply styles
    for row in [4, 5]:
        apply_style(ws[f'A{row}'], styles['subheader'])
        apply_style(ws[f'B{row}'], styles['input'])
    
    for row in range(4, 8):
        apply_style(ws[f'D{row}'], styles['subheader'])
        apply_style(ws[f'E{row}'], styles['formula'])
        if row > 4:
            ws[f'E{row}'].number_format = '$#,##0.00'
    
    wb.save("/home/ubuntu/framing_pricing_spreadsheets/Quick_Price_Calculator.xlsx")

def create_inventory_manager():
    """Create an inventory management workbook"""
    wb = Workbook()
    styles = create_styles()
    ws = wb.active
    ws.title = "Inventory"
    
    # Title
    ws['A1'] = "FRAMING MATERIALS INVENTORY MANAGER"
    apply_style(ws['A1'], styles['header'])
    ws.merge_cells('A1:J1')
    
    # Headers
    headers = ["Item ID", "Description", "Category", "Supplier", "Cost/Unit", "Stock Qty", "Reorder Level", "Last Order", "Usage/Month", "Value"]
    for i, header in enumerate(headers, 1):
        cell = ws.cell(row=3, column=i)
        cell.value = header
        apply_style(cell, styles['header'])
    
    # Sample inventory data
    inventory_items = [
        ("M001", "Basic Pine Frame", "Moulding", "Supplier A", 8.50, 50, 10, "2025-06-01", 15, "=E4*F4"),
        ("M002", "Oak Premium Frame", "Moulding", "Supplier B", 15.75, 25, 5, "2025-06-15", 8, "=E5*F5"),
        ("G001", "Regular Glass", "Glazing", "Glass Co", 3.50, 100, 20, "2025-06-10", 30, "=E6*F6"),
        ("MAT001", "Standard Mat", "Matboard", "Mat Supply", 2.25, 200, 50, "2025-06-05", 45, "=E7*F7")
    ]
    
    for i, data in enumerate(inventory_items, 4):
        for j, value in enumerate(data, 1):
            cell = ws.cell(row=i, column=j)
            if isinstance(value, str) and value.startswith('='):
                cell.value = value
                apply_style(cell, styles['formula'])
                cell.number_format = '$#,##0.00'
            elif j in [5, 10]:  # Cost and Value columns
                cell.value = value
                apply_style(cell, styles['input'])
                cell.number_format = '$#,##0.00'
            else:
                cell.value = value
                apply_style(cell, styles['input'])
    
    wb.save("/home/ubuntu/framing_pricing_spreadsheets/Inventory_Manager.xlsx")

def create_profit_analyzer():
    """Create a profit analysis workbook"""
    wb = Workbook()
    styles = create_styles()
    ws = wb.active
    ws.title = "Profit Analysis"
    
    # Title
    ws['A1'] = "FRAMING BUSINESS PROFIT ANALYZER"
    apply_style(ws['A1'], styles['header'])
    ws.merge_cells('A1:H1')
    
    # Monthly performance tracking
    ws['A3'] = "MONTHLY PERFORMANCE TRACKING"
    apply_style(ws['A3'], styles['subheader'])
    ws.merge_cells('A3:H3')
    
    perf_headers = ["Month", "Revenue", "COGS", "Gross Profit", "Expenses", "Net Profit", "Margin %", "Jobs Count"]
    for i, header in enumerate(perf_headers, 1):
        cell = ws.cell(row=4, column=i)
        cell.value = header
        apply_style(cell, styles['header'])
    
    # Sample monthly data with formulas
    months = ["Jan 2025", "Feb 2025", "Mar 2025", "Apr 2025", "May 2025", "Jun 2025"]
    for i, month in enumerate(months, 5):
        ws[f'A{i}'] = month
        ws[f'B{i}'] = f"=15000+RANDBETWEEN(-2000,5000)"  # Revenue
        ws[f'C{i}'] = f"=B{i}*0.45"                       # COGS (45% of revenue)
        ws[f'D{i}'] = f"=B{i}-C{i}"                       # Gross Profit
        ws[f'E{i}'] = f"=3500+RANDBETWEEN(-500,1000)"     # Expenses
        ws[f'F{i}'] = f"=D{i}-E{i}"                       # Net Profit
        ws[f'G{i}'] = f"=F{i}/B{i}"                       # Margin %
        ws[f'H{i}'] = f"=RANDBETWEEN(40,80)"              # Jobs Count
        
        apply_style(ws[f'A{i}'], styles['input'])
        for col in ['B', 'C', 'D', 'E', 'F', 'G', 'H']:
            apply_style(ws[f'{col}{i}'], styles['formula'])
            if col in ['B', 'C', 'D', 'E', 'F']:
                ws[f'{col}{i}'].number_format = '$#,##0'
            elif col == 'G':
                ws[f'{col}{i}'].number_format = '0.0%'
    
    # Summary statistics
    ws['A12'] = "SUMMARY STATISTICS"
    apply_style(ws['A12'], styles['subheader'])
    
    summary_stats = [
        ("Average Monthly Revenue:", "=AVERAGE(B5:B10)"),
        ("Average Monthly Profit:", "=AVERAGE(F5:F10)"),
        ("Average Profit Margin:", "=AVERAGE(G5:G10)"),
        ("Total YTD Revenue:", "=SUM(B5:B10)"),
        ("Total YTD Profit:", "=SUM(F5:F10)"),
        ("Average Job Value:", "=AVERAGE(B5:B10)/AVERAGE(H5:H10)")
    ]
    
    for i, (label, formula) in enumerate(summary_stats, 13):
        ws[f'A{i}'] = label
        ws[f'B{i}'] = formula
        apply_style(ws[f'A{i}'], styles['subheader'])
        apply_style(ws[f'B{i}'], styles['formula'])
        if '$' in label or 'Revenue' in label or 'Profit' in label or 'Value' in label:
            ws[f'B{i}'].number_format = '$#,##0'
        elif 'Margin' in label:
            ws[f'B{i}'].number_format = '0.0%'
    
    wb.save("/home/ubuntu/framing_pricing_spreadsheets/Profit_Analyzer.xlsx")

if __name__ == "__main__":
    main()
