# Custom Picture Framing Linear Foot Pricing System with PID Controls

## Overview

This comprehensive Excel-based pricing system implements linear foot pricing models for custom picture framing businesses with advanced PID (Proportional-Integral-Derivative) controls for dynamic price adjustments. The system is based on extensive research of industry best practices and provides a complete solution for pricing, cost analysis, and profit optimization.

## System Components

### 1. Custom_Framing_Pricing_System.xlsx (Main System)
**The comprehensive pricing workbook with 6 integrated worksheets:**

#### Master Controls Sheet
- **Global Pricing Variables**: Labor rates, overhead factors, minimum charges
- **Moulding Inventory**: Complete product catalog with PIDs, descriptions, costs, and markups
- **Glazing Options**: Glass and acrylic options with pricing tiers
- **Matboard Options**: Various matboard qualities and pricing
- **Central Control Panel**: Modify any parameter and see changes propagate throughout the system

#### Job Calculator Sheet
- **Interactive Quote Generator**: Input customer details and artwork dimensions
- **Material Selection**: Dropdown menus for easy material selection
- **Automated Calculations**: 
  - Frame perimeter and linear feet calculations
  - Material costs with automatic lookups
  - Labor time estimation based on artwork size
  - Overhead allocation and final pricing
- **Real-time Updates**: All calculations update automatically when inputs change

#### Cost Breakdown Sheet
- **Detailed Cost Analysis**: Component-by-component cost breakdown
- **Profitability Metrics**: Margins, markups, and profit analysis
- **Performance Indicators**: Revenue per linear foot, profit per linear foot
- **Cost Category Analysis**: Understand where your profits come from

#### PID Controls Sheet
- **Dynamic Pricing Engine**: Implements PID control algorithm for pricing optimization
- **Market Conditions Input**: Demand, competition, economic factors
- **Historical Performance Tracking**: 12-month performance data
- **Automated Adjustments**: System recommends pricing adjustments based on:
  - **Proportional Component**: Current market conditions
  - **Integral Component**: Historical performance trends  
  - **Derivative Component**: Rate of change in market conditions
- **Market Adjustment Factors**: Combines multiple market indicators

#### Pricing Scenarios Sheet
- **Scenario Comparison**: Compare pricing under different market conditions
- **Sample Frame Analysis**: See how different frame types perform in various scenarios
- **Revenue Impact Analysis**: Understand financial impact of pricing changes
- **Strategic Planning**: Plan for seasonal variations and economic changes

#### Documentation Sheet
- **Complete Formula Reference**: All key formulas explained
- **Usage Instructions**: Step-by-step guide for system operation
- **PID System Explanation**: Detailed explanation of the control algorithm
- **Best Practices**: Industry recommendations and tips

### 2. Quick_Price_Calculator.xlsx
**Simplified calculator for fast quotes:**
- Basic frame size input
- Three pricing tiers (Basic, Premium, Deluxe)
- Instant price calculations
- Perfect for quick customer estimates

### 3. Inventory_Manager.xlsx
**Material inventory tracking system:**
- Complete inventory database
- Stock level monitoring
- Reorder level alerts
- Usage tracking and forecasting
- Supplier information management
- Inventory value calculations

### 4. Profit_Analyzer.xlsx
**Advanced profitability analysis:**
- Monthly performance tracking
- Revenue and profit trends
- Cost of Goods Sold (COGS) analysis
- Expense tracking
- Key performance indicators
- Summary statistics and benchmarks

## Key Features

### Linear Foot Pricing Model
- **Accurate Calculations**: Precise linear foot calculations including waste factors
- **Flexible Pricing**: Different markups for different material categories
- **Scalable System**: Works for any frame size from small photos to large artwork

### PID Control System
The system implements a sophisticated PID control algorithm that automatically adjusts pricing based on:

1. **Proportional (P) Component**: 
   - Responds to current market conditions
   - Higher demand → increase prices
   - Strong competition → decrease prices

2. **Integral (I) Component**:
   - Responds to historical performance trends
   - Consistently below target margin → increase prices
   - Consistently above target margin → decrease prices

3. **Derivative (D) Component**:
   - Responds to rate of change in performance
   - Rapidly declining performance → make larger adjustments
   - Stable performance → maintain current strategy

### Advanced Formulas

#### Core Pricing Formulas
```excel
Linear Feet = 2 × (Width + Height) / 12
Moulding Cost = Linear Feet × Price per Linear Foot
Area = Width × Height / 144
Total Cost = Moulding + Glazing + Matboard + Labor + Hardware
Final Price = MAX(Total Cost × (1 + Overhead), Minimum Charge)
```

#### PID Control Formulas
```excel
Error = Target Margin - Current Margin
Proportional = Kp × Error
Integral = Ki × (Historical Average - Target)
Derivative = Kd × (Current Change Rate)
PID Output = Proportional + Integral + Derivative
```

#### Market Adjustment Formulas
```excel
Market Factor = (Demand × Economic × Seasonal)^0.5 - 0.5
Final Markup = Base Markup + PID Output + Market Factor
```

## Getting Started

### Step 1: Initial Setup
1. Open `Custom_Framing_Pricing_System.xlsx`
2. Go to the "Master Controls" sheet
3. Update global variables:
   - Set your labor rate ($/hour)
   - Set overhead factor (typically 15-20%)
   - Set minimum job charge
   - Set waste factor (typically 8 inches)

### Step 2: Configure Inventory
1. Update the moulding inventory table with your actual products
2. Enter wholesale costs and desired markup percentages
3. Add glazing and matboard options with pricing
4. The retail prices will calculate automatically

### Step 3: Generate Quotes
1. Go to the "Job Calculator" sheet
2. Enter customer information and artwork dimensions
3. Select materials using the PID codes
4. Review the calculated price and cost breakdown
5. Adjust if needed based on special circumstances

### Step 4: Monitor Performance
1. Use the "Cost Breakdown" sheet to analyze profitability
2. Update the "PID Controls" sheet with current market conditions
3. Review historical performance data monthly
4. Apply recommended adjustments to your Master Controls

### Step 5: Strategic Planning
1. Use the "Pricing Scenarios" sheet to plan for different market conditions
2. Analyze the impact of pricing changes before implementing them
3. Develop seasonal pricing strategies

## PID Control System Usage

### Market Condition Inputs (Scale 0.0 to 1.0)
- **Market Demand**: 0.0 (Very Low) to 1.0 (Very High)
- **Competition Level**: 0.0 (Low Competition) to 1.0 (High Competition)  
- **Economic Conditions**: 0.0 (Poor Economy) to 1.0 (Excellent Economy)
- **Seasonal Factor**: 0.0 (Off-season) to 1.0 (Peak Season)

### PID Parameters (Recommended Starting Values)
- **Proportional Gain (Kp)**: 1.0 (Sensitivity to current conditions)
- **Integral Gain (Ki)**: 0.1 (Response to historical trends)
- **Derivative Gain (Kd)**: 0.05 (Response to rate of change)
- **Target Margin**: 50% (Your desired profit margin)

### Interpreting PID Output
- **Positive Output**: Increase prices (market conditions favor higher pricing)
- **Negative Output**: Decrease prices (market conditions favor lower pricing)
- **Large Output**: Make significant adjustments
- **Small Output**: Make minor adjustments

## Best Practices

### Pricing Strategy
1. **Regular Review**: Update costs and market conditions monthly
2. **Competitive Analysis**: Monitor competitor pricing quarterly
3. **Customer Feedback**: Adjust based on customer price sensitivity
4. **Seasonal Planning**: Prepare pricing strategies for peak and off-seasons

### System Maintenance
1. **Backup Regularly**: Keep copies of your configured spreadsheets
2. **Update Inventory**: Keep material costs current
3. **Track Performance**: Monitor actual vs. projected margins
4. **Refine PID Settings**: Adjust PID parameters based on results

### Profitability Optimization
1. **Focus on High-Margin Items**: Promote premium materials
2. **Bundle Services**: Create package deals to increase average sale
3. **Monitor Labor Efficiency**: Track actual vs. estimated labor time
4. **Optimize Inventory**: Focus on fast-moving, profitable items

## Troubleshooting

### Common Issues
1. **Prices Too High**: Check markup percentages, reduce if necessary
2. **Prices Too Low**: Verify all costs are included, increase markups
3. **PID Oscillation**: Reduce Kp and Kd values
4. **Slow PID Response**: Increase Ki value

### Formula Errors
- Ensure all PID references point to correct cells
- Check that lookup tables have consistent formatting
- Verify that percentage values are entered correctly (0.5 for 50%)

## Support and Customization

### Customization Options
- Add new material categories
- Modify labor time calculations
- Adjust PID algorithm parameters
- Create custom scenario analyses

### Advanced Features
- Link to external inventory systems
- Create automated reports
- Implement dynamic pricing based on real-time data
- Add customer-specific pricing tiers

## File Structure
```
framing_pricing_spreadsheets/
├── Custom_Framing_Pricing_System.xlsx    # Main comprehensive system
├── Quick_Price_Calculator.xlsx           # Simplified calculator
├── Inventory_Manager.xlsx                # Material inventory tracking
├── Profit_Analyzer.xlsx                  # Advanced profitability analysis
├── README.md                             # This documentation
└── create_framing_spreadsheets.py        # Source code for regeneration
```

## Version Information
- **Version**: 1.0
- **Created**: June 22, 2025
- **Based on**: Comprehensive industry research and best practices
- **Compatible with**: Microsoft Excel 2016 or later, LibreOffice Calc

## License and Usage
This pricing system is designed for use by custom picture framing businesses. Feel free to modify and adapt the spreadsheets to meet your specific business needs.

---

*For questions or support, refer to the Documentation sheet within the main Excel file or consult with a business analyst familiar with pricing systems.*
