# Quick Reference Guide - Framing Pricing System

## Essential Formulas

### Basic Calculations
| Formula | Excel Code | Purpose |
|---------|------------|---------|
| Linear Feet | `=2*(Width+Height)/12` | Convert perimeter to linear feet |
| Area (sq ft) | `=Width*Height/144` | Convert dimensions to square feet |
| Perimeter + Waste | `=Perimeter+WasteFactor` | Add material waste allowance |

### Pricing Formulas
| Component | Formula | Example |
|-----------|---------|---------|
| Moulding Cost | `=LinearFeet*PricePerFoot` | `=6*15.75` |
| Glazing Cost | `=Area*PricePerSqFt` | `=2.22*8.75` |
| Labor Cost | `=Hours*HourlyRate` | `=1.5*45` |
| Total Cost | `=SUM(Materials+Labor)` | `=SUM(B5:B8)` |
| Final Price | `=TotalCost*(1+Overhead)` | `=150*1.15` |

### PID Control Formulas
| Component | Formula | Purpose |
|-----------|---------|---------|
| Error | `=Setpoint-Current` | Difference from target |
| Proportional | `=Kp*Error` | Current condition response |
| Integral | `=Ki*HistoricalError` | Historical trend response |
| Derivative | `=Kd*RateOfChange` | Change rate response |
| PID Output | `=P+I+D` | Combined adjustment factor |

## Quick Setup Checklist

### Initial Configuration
- [ ] Set labor rate in Master Controls (B4)
- [ ] Set overhead factor in Master Controls (B5)
- [ ] Set minimum job charge in Master Controls (B6)
- [ ] Update moulding inventory with your products
- [ ] Add glazing options and pricing
- [ ] Add matboard options and pricing

### Daily Operations
- [ ] Enter customer info in Job Calculator
- [ ] Input artwork dimensions
- [ ] Select materials using PID codes
- [ ] Review calculated price
- [ ] Check cost breakdown for profitability

### Weekly/Monthly Tasks
- [ ] Update market conditions in PID Controls
- [ ] Review historical performance data
- [ ] Apply PID recommendations to pricing
- [ ] Update material costs if changed
- [ ] Analyze profit margins and trends

## Common PID Codes

### Moulding Codes
| PID | Description | Typical Price/LF |
|-----|-------------|------------------|
| M001 | Basic Wood Frame | $12-18 |
| M002 | Premium Oak Frame | $25-35 |
| M003 | Metal Silver Frame | $20-30 |
| M004 | Ornate Gold Frame | $40-60 |
| M005 | Modern Black Frame | $15-25 |

### Glazing Codes
| GID | Description | Typical Price/SqFt |
|-----|-------------|-------------------|
| G001 | Regular Glass | $8-12 |
| G002 | Non-Glare Glass | $18-25 |
| G003 | UV Protection Glass | $25-35 |
| G004 | Museum Glass | $45-65 |
| G005 | Acrylic Standard | $10-15 |

### Matboard Codes
| MID | Description | Typical Price/SqFt |
|-----|-------------|-------------------|
| MAT001 | Standard Mat | $6-9 |
| MAT002 | Acid-Free Mat | $10-15 |
| MAT003 | Museum Mat | $18-25 |
| MAT004 | Fabric Mat | $25-35 |
| MAT005 | Double Mat | $15-20 |

## PID Control Quick Guide

### Market Condition Scales (0.0 to 1.0)
- **Market Demand**: 0.2 (Very Low) → 0.8 (High) → 1.0 (Extremely High)
- **Competition**: 0.2 (Low Competition) → 0.6 (Moderate) → 1.0 (Intense)
- **Economic Conditions**: 0.3 (Recession) → 0.7 (Good) → 1.0 (Booming)
- **Seasonal Factor**: 0.4 (Off-season) → 0.8 (Busy) → 1.0 (Peak Holiday)

### PID Parameter Guidelines
| Parameter | Conservative | Moderate | Aggressive |
|-----------|-------------|----------|------------|
| Kp (Proportional) | 0.5 | 1.0 | 2.0 |
| Ki (Integral) | 0.05 | 0.1 | 0.2 |
| Kd (Derivative) | 0.02 | 0.05 | 0.1 |

### Interpreting PID Output
| Output Range | Action | Example |
|--------------|--------|---------|
| +0.1 to +0.3 | Small price increase | Raise markups 10-30% |
| +0.3 to +0.5 | Moderate price increase | Raise markups 30-50% |
| +0.5+ | Large price increase | Raise markups 50%+ |
| -0.1 to -0.3 | Small price decrease | Lower markups 10-30% |
| -0.3 to -0.5 | Moderate price decrease | Lower markups 30-50% |
| -0.5+ | Large price decrease | Lower markups 50%+ |

## Troubleshooting Quick Fixes

### Price Too High
1. Check markup percentages in Master Controls
2. Verify labor rate is reasonable
3. Review overhead factor (should be 15-25%)
4. Consider market conditions in PID Controls

### Price Too Low
1. Ensure all costs are included
2. Check if minimum charge is appropriate
3. Verify material costs are current
4. Review profit margin targets

### PID System Issues
1. **Oscillating prices**: Reduce Kp and Kd values
2. **Slow response**: Increase Ki value
3. **Overreacting**: Reduce all PID gains by 50%
4. **Not responding**: Increase Kp value

### Formula Errors
1. Check cell references in lookup formulas
2. Ensure PID codes match exactly
3. Verify percentage formats (0.5 = 50%)
4. Check for circular references

## Sample Calculations

### Example 1: 16x20 Basic Frame
```
Dimensions: 16" x 20"
Perimeter: 2*(16+20) = 72 inches
Linear Feet: 72/12 = 6 LF
Moulding (M001): 6 LF × $12/LF = $72
Area: 16*20/144 = 2.22 sq ft
Glazing (G001): 2.22 × $8/sq ft = $18
Matboard (MAT001): 2.22 × $6/sq ft = $13
Labor: 1.0 hours × $45/hour = $45
Hardware: $15
Subtotal: $163
Overhead (15%): $24
Total: $187
```

### Example 2: 24x36 Premium Frame
```
Dimensions: 24" x 36"
Perimeter: 2*(24+36) = 120 inches
Linear Feet: 120/12 = 10 LF
Moulding (M002): 10 LF × $25/LF = $250
Area: 24*36/144 = 6 sq ft
Glazing (G003): 6 × $25/sq ft = $150
Matboard (MAT002): 6 × $10/sq ft = $60
Labor: 2.0 hours × $45/hour = $90
Hardware: $20
Subtotal: $570
Overhead (15%): $86
Total: $656
```

## Emergency Contact Information
- **System Issues**: Check Documentation sheet in main Excel file
- **Formula Problems**: Refer to Master Controls sheet for examples
- **Business Questions**: Consult with pricing specialist or business advisor

---
*Keep this guide handy for quick reference during daily operations*
